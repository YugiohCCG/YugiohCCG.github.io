--ONIBI
local s,id=GetID()
local STRING_ID=133713649
function s.initial_effect(c)
	--Spirit return
	local er=Effect.CreateEffect(c)
    er:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
    er:SetCode(EVENT_SUMMON_SUCCESS)
    er:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
    er:SetOperation(s.spiritreg)
    c:RegisterEffect(er)
    local erf=er:Clone()
    erf:SetCode(EVENT_FLIP)
    c:RegisterEffect(erf)
	--Cannot be Special Summoned
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
	e1:SetCode(EFFECT_SPSUMMON_CONDITION)
	e1:SetValue(aux.FALSE)
	c:RegisterEffect(e1)
	--Normal Summon 1 Spirit monster
	local e2=Effect.CreateEffect(c)
	e2:SetDescription(aux.Stringid(STRING_ID,0))
	e2:SetCategory(CATEGORY_SUMMON+CATEGORY_RELEASE+CATEGORY_TOHAND+CATEGORY_SEARCH)
	e2:SetType(EFFECT_TYPE_QUICK_O)
	e2:SetCode(EVENT_FREE_CHAIN)
	e2:SetRange(LOCATION_HAND+LOCATION_MZONE)
	e2:SetCountLimit(1,id)
	e2:SetCondition(s.sumcon)
	e2:SetCost(s.sumcost)
	e2:SetTarget(s.sumtg)
	e2:SetOperation(s.sumop)
	c:RegisterEffect(e2)
end
function s.sumcon(e,tp,eg,ep,ev,re,r,rp)
	return Duel.IsMainPhase()
end
function s.spiritfilter(c)
	return c:IsType(TYPE_SPIRIT) and c:IsSummonable(true,nil)
end
function s.onibifilter(c)
	return c:IsCode(id) and c:IsSummonable(true,nil)
end
function s.canrelease(e,tp)
	local c=e:GetHandler()
	return c:IsLocation(LOCATION_HAND) and c:IsReleasable()
		and Duel.IsExistingMatchingCard(s.spiritfilter,tp,LOCATION_HAND,0,1,c)
end
function s.cannormal(e,tp)
	local c=e:GetHandler()
	if c:IsLocation(LOCATION_HAND) and c:IsSummonable(true,nil) then return true end
	return Duel.IsExistingMatchingCard(s.onibifilter,tp,LOCATION_HAND,0,1,c)
end
function s.sumcost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return s.canrelease(e,tp) or s.cannormal(e,tp) end
	local rel=s.canrelease(e,tp)
	local norm=s.cannormal(e,tp)
	if rel and (not norm or Duel.SelectYesNo(tp,aux.Stringid(STRING_ID,1))) then
		Duel.Release(e:GetHandler(),REASON_COST)
		e:SetLabel(1)
	else
		e:SetLabel(0)
	end
end
function s.sumtg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then
		return s.canrelease(e,tp) or s.cannormal(e,tp)
	end
	Duel.SetOperationInfo(0,CATEGORY_SUMMON,nil,1,0,0)
end
function s.thfilter(c)
	return c:IsType(TYPE_SPIRIT) and not c:IsCode(id) and c:IsAbleToHand()
end
function s.sumop(e,tp,eg,ep,ev,re,r,rp)
	local f=s.onibifilter
	if e:GetLabel()==1 then f=s.spiritfilter end
	if not Duel.IsExistingMatchingCard(f,tp,LOCATION_HAND,0,1,nil) then return end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SUMMON)
	local tc=Duel.SelectMatchingCard(tp,f,tp,LOCATION_HAND,0,1,1,nil):GetFirst()
	if not tc then return end
	-- In-chain Normal Summons finish after the chain; continue on actual success.
	if tc:IsCode(id) then
		local follow=Effect.CreateEffect(e:GetHandler())
		follow:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
		follow:SetCode(EVENT_SUMMON_SUCCESS)
		follow:SetReset(RESET_PHASE+PHASE_END)
		local neg=follow:Clone()
		neg:SetCode(EVENT_SUMMON_NEGATED)
		local function clear() follow:Reset() neg:Reset() end
		follow:SetOperation(function(te,p,eg)
			if not eg:IsContains(tc) then return end
			clear()
			if tc:IsLocation(LOCATION_MZONE) then s.searchop(tp) end
		end)
		neg:SetOperation(function(te,p,eg) if eg:IsContains(tc) then clear() end end)
		Duel.RegisterEffect(follow,tp)
		Duel.RegisterEffect(neg,tp)
	end
	Duel.Summon(tp,tc,true,nil)
end
function s.searchop(tp)
	if Duel.IsExistingMatchingCard(s.thfilter,tp,LOCATION_DECK,0,1,nil)
		and Duel.SelectYesNo(tp,aux.Stringid(STRING_ID,2)) then
		Duel.BreakEffect()
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_ATOHAND)
		local g=Duel.SelectMatchingCard(tp,s.thfilter,tp,LOCATION_DECK,0,1,1,nil)
		if #g>0 and Duel.SendtoHand(g,nil,REASON_EFFECT)>0 then
			Duel.ConfirmCards(1-tp,g)
		end
	end
end

function s.spiritreg(e,tp)
    local c=e:GetHandler()
    local er=Effect.CreateEffect(c)
    er:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_F)
    er:SetDescription(1104)
    er:SetCategory(CATEGORY_TOHAND)
    er:SetCode(EVENT_PHASE+PHASE_END)
    er:SetRange(LOCATION_MZONE)
    er:SetCountLimit(1,{id,1})
    er:SetReset(RESET_EVENT+0xd7e0000+RESET_PHASE+PHASE_END)
    er:SetCondition(aux.SpiritReturnConditionForced)
    er:SetTarget(aux.SpiritReturnTargetForced)
    er:SetOperation(aux.SpiritReturnOperation)
    c:RegisterEffect(er)
    local eo=er:Clone()
    eo:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_TRIGGER_O)
    eo:SetCondition(aux.SpiritReturnConditionOptional)
    eo:SetTarget(aux.SpiritReturnTargetOptional)
    c:RegisterEffect(eo)
end
