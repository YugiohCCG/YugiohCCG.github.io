local s,id=GetID()
function s.initial_effect(c)
	--Activate
	local e1=Effect.CreateEffect(c)
	e1:SetCategory(CATEGORY_TOHAND+CATEGORY_SEARCH+CATEGORY_DICE)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_FREE_CHAIN)
	e1:SetTarget(s.target)
	e1:SetOperation(s.activate)
	c:RegisterEffect(e1)
end
s.roll_dice=true
function s.target(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetFieldGroupCount(tp,LOCATION_DECK,0)>0 end
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_CODE)
	local ac=Duel.AnnounceCard(tp)
	Duel.SetTargetParam(ac)
	Duel.SetOperationInfo(0,CATEGORY_ANNOUNCE,nil,0,tp,0)
	Duel.SetOperationInfo(0,CATEGORY_DICE,nil,0,tp,1)
end
function s.activate(e,tp,eg,ep,ev,re,r,rp)
	local ac=Duel.GetChainInfo(0,CHAININFO_TARGET_PARAM)
	local d=Duel.TossDice(tp,1)
	if Duel.GetFieldGroupCount(tp,LOCATION_DECK,0)==0 then
		Duel.SetLP(tp,Duel.GetLP(tp)-2000)
		return
	end
	local ct=math.min(d,Duel.GetFieldGroupCount(tp,LOCATION_DECK,0))
	Duel.ConfirmDecktop(tp,ct)
	local g=Duel.GetDecktopGroup(tp,ct)
	local tg=g:Filter(Card.IsCode,nil,ac)
	local added=false
	if #tg>0 then
		Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_ATOHAND)
		local tc=tg:Select(tp,1,1,nil):GetFirst()
		if tc and Duel.SendtoHand(tc,nil,REASON_EFFECT)>0
			and tc:IsLocation(LOCATION_HAND) and tc:IsControler(tp) then
			Duel.ConfirmCards(1-tp,tc)
			added=true
		end
	end
	if not added then
		Duel.SetLP(tp,Duel.GetLP(tp)-2000)
	end
	Duel.ShuffleDeck(tp)
end
