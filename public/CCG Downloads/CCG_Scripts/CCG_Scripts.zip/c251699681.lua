--Bear Trap
local s,id=GetID()
local STRING_ID=133699681
local SET_VIR_PEDICAE_MORTIS=0x39e2
function s.initial_effect(c)
	--Negate a Summon
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(STRING_ID,0))
	e1:SetCategory(CATEGORY_DISABLE_SUMMON+CATEGORY_DESTROY)
	e1:SetType(EFFECT_TYPE_ACTIVATE)
	e1:SetCode(EVENT_SUMMON)
	if Duel.GetReadyChain then
		e1:SetCountLimit(1,id+EFFECT_COUNT_CODE_OATH)
	else
		e1:SetCountLimit(1,id,1) -- EFFECT_COUNT_CODE_OATH in modern cores
	end
	e1:SetCondition(s.sumcon)
	e1:SetTarget(s.sumtg)
	e1:SetOperation(s.sumop)
	c:RegisterEffect(e1)
	local e2=e1:Clone()
	e2:SetCode(EVENT_FLIP_SUMMON)
	c:RegisterEffect(e2)
	local e3=e1:Clone()
	e3:SetCode(EVENT_SPSUMMON)
	c:RegisterEffect(e3)
	--Negate an attack
	local e4=Effect.CreateEffect(c)
	e4:SetDescription(aux.Stringid(STRING_ID,0))
	e4:SetCategory(CATEGORY_DESTROY)
	e4:SetType(EFFECT_TYPE_ACTIVATE)
	e4:SetCode(EVENT_ATTACK_ANNOUNCE)
	if Duel.GetReadyChain then
		e4:SetCountLimit(1,id+EFFECT_COUNT_CODE_OATH)
	else
		e4:SetCountLimit(1,id,1) -- EFFECT_COUNT_CODE_OATH in modern cores
	end
	e4:SetCondition(s.atkcon)
	e4:SetTarget(s.atktg)
	e4:SetOperation(s.atkop)
	c:RegisterEffect(e4)
	--Set this card from the GY
	local e5=Effect.CreateEffect(c)
	e5:SetDescription(aux.Stringid(STRING_ID,1))
	if type(aux.CCGSetEffects)~="table" then aux.CCGSetEffects={} end aux.CCGSetEffects[e5]=true
	e5:SetType(EFFECT_TYPE_IGNITION)
	e5:SetRange(LOCATION_GRAVE)
	e5:SetCondition(s.setcon)
	e5:SetTarget(s.settg)
	e5:SetOperation(s.setop)
	c:RegisterEffect(e5)
	--Track each activation for effects that count "Bear Trap" activations
	if not s.global_check then
		s.global_check=true
		local ge=Effect.CreateEffect(c)
		ge:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
		ge:SetCode(EVENT_CHAINING)
		ge:SetOperation(s.checkop)
		Duel.RegisterEffect(ge,0)
		local gn=ge:Clone()
		gn:SetCode(EVENT_CHAIN_NEGATED)
		gn:SetOperation(s.uncheckop)
		Duel.RegisterEffect(gn,0)
	end
end
s.listed_series={SET_VIR_PEDICAE_MORTIS}
function s.checkop(e,tp,eg,ep,ev,re,r,rp)
	if re:IsHasType(EFFECT_TYPE_ACTIVATE) and re:GetHandler():IsCode(id) then
		Duel.RegisterFlagEffect(rp,id,0,0,1)
		Duel.RegisterFlagEffect(rp,id+100,RESET_PHASE+PHASE_END,0,1)
	end
end
function s.sumcon(e,tp,eg,ep,ev,re,r,rp)
	if tp==ep then return false end
	if Duel.GetReadyChain then return aux.NegateSummonCondition(e,tp,eg,ep,ev,re,r,rp) end
	return Duel.GetCurrentChain()==0
end
function s.sumtg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	Duel.SetOperationInfo(0,CATEGORY_DISABLE_SUMMON,eg,eg:GetCount(),0,0)
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,eg,eg:GetCount(),0,0)
end
function s.sumop(e,tp,eg,ep,ev,re,r,rp)
	if Duel.NegateSummon(eg) then
		Duel.Destroy(eg,REASON_EFFECT)
	end
end
function s.atkcon(e,tp,eg,ep,ev,re,r,rp)
	local ac=Duel.GetAttacker()
	return ac and ac:IsControler(1-tp)
end
function s.atktg(e,tp,eg,ep,ev,re,r,rp,chk)
	local ac=Duel.GetAttacker()
	if chk==0 then return ac~=nil end
	Duel.SetOperationInfo(0,CATEGORY_DESTROY,ac,1,0,0)
end
function s.atkop(e,tp,eg,ep,ev,re,r,rp)
	local ac=Duel.GetAttacker()
	if ac and Duel.NegateAttack() and ac:IsRelateToBattle() then
		Duel.Destroy(ac,REASON_EFFECT)
	end
end
function s.virfilter(c)
	return c:IsFaceup() and c:IsSetCard(SET_VIR_PEDICAE_MORTIS) and c:IsType(TYPE_MONSTER)
end
function s.setcon(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():GetTurnID()~=Duel.GetTurnCount()
		and Duel.IsExistingMatchingCard(s.virfilter,tp,LOCATION_MZONE,0,1,nil)
end
function s.settg(e,tp,eg,ep,ev,re,r,rp,chk)
	local c=e:GetHandler()
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_SZONE)>0 and c:IsSSetable()
		and aux.NecroValleyFilter()(c) end
	Duel.SetOperationInfo(0,CATEGORY_LEAVE_GRAVE,c,1,0,0)
end
function s.setop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	if c:IsRelateToEffect(e) and aux.NecroValleyFilter()(c) and c:IsSSetable()
		and Duel.GetLocationCount(tp,LOCATION_SZONE)>0 and Duel.SSet(tp,c)~=0 then
		local e1=Effect.CreateEffect(c)
		e1:SetType(EFFECT_TYPE_SINGLE)
		e1:SetCode(EFFECT_LEAVE_FIELD_REDIRECT)
		e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
		e1:SetReset(RESET_EVENT+RESETS_REDIRECT)
		e1:SetValue(LOCATION_REMOVED)
		c:RegisterEffect(e1)
	end
end

--An activation that was negated does not count as an activated card.
function s.uncheckop(e,tp,eg,ep,ev,re,r,rp)
	if not re:IsHasType(EFFECT_TYPE_ACTIVATE) or not re:GetHandler():IsCode(id) then return end
	for _,code in ipairs({id,id+100}) do
		local ct=Duel.GetFlagEffect(rp,code)
		Duel.ResetFlagEffect(rp,code)
		for i=1,ct-1 do
			Duel.RegisterFlagEffect(rp,code,code==id and 0 or RESET_PHASE+PHASE_END,0,1)
		end
	end
end
