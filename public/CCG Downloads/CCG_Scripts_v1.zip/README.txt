Place your custom YGO Omega script files in this folder before building the installer.
They will be copied to YGO Omega_Data\Files\Scripts\CCG_Scripts_v1 on install.
